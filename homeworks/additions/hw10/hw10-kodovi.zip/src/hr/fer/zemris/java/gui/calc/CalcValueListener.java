package hr.fer.zemris.java.gui.calc;

public interface CalcValueListener {
	void valueChanged(CalcModel model);
}